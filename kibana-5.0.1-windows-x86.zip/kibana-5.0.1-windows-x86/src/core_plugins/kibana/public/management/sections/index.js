import 'plugins/kibana/management/sections/settings';
import 'plugins/kibana/management/sections/objects';
import 'plugins/kibana/management/sections/indices';
