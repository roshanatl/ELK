define(function (require) {
  return function savedSearchObjectFn(savedSheets) {
    return savedSheets;
  };
});
