'use strict';

Object.defineProperty(exports, '__esModule', {
  value: true
});

var _path = require('path');

var DEV_SSL_CERT_PATH = (0, _path.resolve)(__dirname, '../../test/dev_certs/server.crt');
exports.DEV_SSL_CERT_PATH = DEV_SSL_CERT_PATH;
var DEV_SSL_KEY_PATH = (0, _path.resolve)(__dirname, '../../test/dev_certs/server.key');
exports.DEV_SSL_KEY_PATH = DEV_SSL_KEY_PATH;
